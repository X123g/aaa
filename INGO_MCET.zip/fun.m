function [fitness] = fun(I,Thresh)

    fitness = KullBackB(I,Thresh);
end