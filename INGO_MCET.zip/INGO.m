
function[Best_score,Best_pos,INGO_curve]=INGO(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness)

lowerbound=ones(1,dimension).*(lowerbound);                              % Lower limit for variables
upperbound=ones(1,dimension).*(upperbound);                              % Upper limit for variables

%% INITIALIZATION
X=initializationNew(SearchAgents,dimension,upperbound,lowerbound, fitness); %���������ʼ���ӷ���������Ƶĵ���Ⱥ��ʼ��
% for i=1:dimension
%     X(:,i) = lowerbound(i)+rand(SearchAgents,1).*(upperbound(i) - lowerbound(i));                          % Initial population
% end
for i =1:SearchAgents
     Flag4ub=X(i,:)>upperbound;
     Flag4lb=X(i,:)<lowerbound;
     X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+upperbound.*Flag4ub+lowerbound.*Flag4lb;
        for h=1:size(X,1)
            X(h,:)= fix(sort(X(h,:)));
        end
    L=X(i,:);
    fit(i)=fitness(L);
end
%%

for t=1:Max_iterations
    %% update the best condidate solution
    [best , location]=min(fit);
    if t==1
        Xbest=X(location,:);                                           % Optimal location
        fbest=best;                                           % The optimization objective function
    elseif best<fbest
        fbest=best;
        Xbest=X(location,:);
    end
     
    %% UPDATE location of food
    
    X_FOOD=[];
    k=randperm(SearchAgents,1);
    X_FOOD=X(k,:);
    F_FOOD=fit(k);
    
    %%
    for i=1:SearchAgents
        
        %% PHASE 1: Moving towards prey (exploration phase)
        I=round(1+rand(1,1));
        if fit(i)> F_FOOD
            X_new=X(i,:)+ rand(1,1).*(X_FOOD-I.* X(i,:)); %Eq(4)
        else
            X_new=X(i,:)+ rand(1,1).*(X(i,:)-1.*X_FOOD); %Eq(4)
        end
        X_new= max(X_new,lowerbound);X_new = min(X_new,upperbound);
        
        % Updating X_i using (5)
        f_new = fitness(X_new);
        if f_new <= fit (i)
            X(i,:) = X_new;
            fit (i)=f_new;
        end
        %% END PHASE 1: Moving towards prey (exploration phase)
          %% �Ľ��㣺��Ϸ���ѧϰ����
    %������λ�ã�͸��������ѧϰ����
    n = 1.2*10^4;
    Temp = (upperbound + lowerbound)./2 + (upperbound + lowerbound)./(2*n) - Xbest./n;
     %�߽�Խ�紦��
    Flag4ub=Temp>upperbound;
    Flag4lb=Temp<lowerbound;
    Temp=(Temp.*(~(Flag4ub+Flag4lb)))+upperbound.*Flag4ub+lowerbound.*Flag4lb; 
    fitTemp = fitness(Temp);%������Ӧ��ֵ
    if(fitTemp<fbest)
        fbest = fitTemp;
        Xbest = Temp;
%        X(BestIndex,:) = Temp;
    end
     %�����λ�ã��������ѧϰ����
     [fitWorst,indexWorst] = max(fit(i));
     WorstPosition = X(indexWorst);
     Temp = upperbound + rand(1,dimension).*(lowerbound - WorstPosition);
     Temp=(Temp.*(~(Flag4ub+Flag4lb)))+upperbound.*Flag4ub+lowerbound.*Flag4lb; 
    fitTemp = fitness(Temp);%������Ӧ��ֵ
    if(fitTemp<fitWorst)
       fit(indexWorst) = fitTemp;
       X(indexWorst,:) = Temp;
    end
        %% PHASE 2: Winging on the water surface (exploitation phase)
        X_new=X(i,:)+0.2*(1-t/Max_iterations).*(2*rand(1,dimension)-1).*X(i,:);% Eq(6)
        X_new= max(X_new,lowerbound);X_new = min(X_new,upperbound);
        
        % Updating X_i using (7)
        f_new = fitness(X_new);
        if f_new <= fit (i)
            X(i,:) = X_new;
            fit (i)=f_new;
        end
        %% END PHASE 2: Winging on the water surface (exploitation phase)
    end
    best_so_far(t)=fbest;
    average(t) = mean (fit);
    
end
Best_score=fbest;
Best_pos=Xbest;
INGO_curve=best_so_far;
end

