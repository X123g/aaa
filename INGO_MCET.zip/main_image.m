clear all
clc
tic
I = imread('E:\ͼ��������\INGO_MCET\1.jpg');%��ȡͼ��
I1 = I(:,:,1);
I2 = I(:,:,2);
I3 = I(:,:,3);
%%
dim=4;
SearchAgents_no=20;
Max_iteration=100;
lb = ones(1,dim);
ub = 255*ones(1,dim);
Best_score=zeros(3,1);
%%
%I1
fobj =@(thresh)fun(I1,thresh);
[Best_score(1,1),Best_pos_R,curve_R_INGO]=INGO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
Iout_R=YuZhiplot(I1,Best_pos_R);
%I2
fobj =@(thresh)fun(I2,thresh);
[Best_score(2,1),Best_pos_G,curve_G_INGO]=INGO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
Iout_G=YuZhiplot(I2,Best_pos_G);

%%
%I3
fobj =@(thresh)fun(I3,thresh);
[Best_score(3,1),Best_pos_B,curve_B_INGO]=INGO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
Iout_B=YuZhiplot(I3,Best_pos_B);

%%
Best_score_MCET=1./Best_score;
Iout = uint8(cat(3,Iout_R,Iout_G,Iout_B));imshow(Iout);
%%
f1=FSIM(Iout,I);
display(['The FSIM value by INGO_MCET is  ', num2str(f1)]);
s1=SSIM(Iout,I);
display(['The SSIM value by INGO_MCET is  ', num2str(s1)]);
p1 = psnr(Iout,I);
display(['The PSNR value by INGO_MCET is  ', num2str(p1)]);
f1=FSIM(Iout,I);
toc




