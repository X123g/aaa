function [Iout]=YuZhiplot(I,thresh)
Iout=zeros(size(I));
thresh = sort(thresh);%��ֵ����
n=max(size(thresh));%dim����
for i=1:n+1
    if(i==1)
        Iout(I<=thresh(i)&I>=0)=0;
    elseif i==n+1
        Iout(I>=thresh(i-1)&I<=255)=thresh(i-1);
    else
        Iout(I<=thresh(i)&I>=thresh(i-1))=thresh(i-1);
    end
end